// const rp = require('request-promise');
const all = require('./final_fi.json')

function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

async function query(event) {
  let res = all
  if (event.objectid) {
    const r = res.filter(f => (f.objectid == event.objectid));
    if (r.length > 0) return r[0]
    else return false
  }
  if (event.district && event.district !== "any") {
    res = res.filter(f => {
      return f.district == event.district;
    });
  }
  if (event.category && event.category !== "any") {
    res = res.filter(f => {
      return f.category == event.category;
    });
  }
  return shuffle(res).slice(0, 5)
};

module.exports.handler = async (event) => {
  return query(event)
}

// Uncomment this code below to test your function
(async function() {
  const event = {
    district: 'any',
    category: "Cheffes"
  }
  const q = await query(event)
  console.log(JSON.stringify(q, null, 2))
})();
